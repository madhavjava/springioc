package bookresource;

public class Maths implements BookInterface{
     String name;
	@Override
	public void setName() {
		// TODO Auto-generated method stub
		name="maths";
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
		
	}

}
