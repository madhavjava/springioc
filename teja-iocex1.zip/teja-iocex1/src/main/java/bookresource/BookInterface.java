package bookresource;

public interface BookInterface {
	public void setName();
	public String getName();

}
